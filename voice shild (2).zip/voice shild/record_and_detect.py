import sounddevice as sd
from scipy.io.wavfile import write
import datetime
from detect_ai_voice import detect_voice

# Step 1: Detect the pre-existing file (test.wav)
print("🔍 Analyzing test.wav ...")
initial_probability = detect_voice("test.wav")

if initial_probability > 0.5:
    print(f"❌ AI Voice Detected in test.wav | Probability: {initial_probability:.3f}")
else:
    print(f"✅ Human Voice Detected in test.wav | Probability: {initial_probability:.3f}")


