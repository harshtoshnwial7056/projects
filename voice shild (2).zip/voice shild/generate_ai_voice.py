import pyttsx3
import os

# Initialize the TTS engine
engine = pyttsx3.init()

# Set properties (optional)
engine.setProperty('rate', 150)  # Speed of speech
engine.setProperty('volume', 1)  # Volume level (0.0 to 1.0)

# List of fake AI sentences (you can add more)
sentences = [
 "MERA NAAM MONTU HAI "
 "MAI CRACK HO"
]

# Output folder
output_folder = "ai_voice_samples"
os.makedirs(output_folder, exist_ok=True)

# Generate and save each voice
for i, text in enumerate(sentences):
    filename = os.path.join(output_folder, f"ai_sample_{i+1}.mp3")
    engine.save_to_file(text, filename)
    print(f"Saved: {filename}")

# Run the speech engine to process saving
engine.runAndWait()
print("✅ All AI voice samples generated.")
