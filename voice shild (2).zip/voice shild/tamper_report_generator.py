# tamper_report_generator.py

import librosa
import numpy as np

def detect_pitch_shift(test_path, reference_path):
    y_test, sr_test = librosa.load(test_path)
    y_ref, sr_ref = librosa.load(reference_path)

    pitch_test = librosa.piptrack(y=y_test, sr=sr_test)[0]
    pitch_ref = librosa.piptrack(y=y_ref, sr=sr_ref)[0]

    test_mean = np.mean(pitch_test[pitch_test > 0])
    ref_mean = np.mean(pitch_ref[pitch_ref > 0])

    shift = round(test_mean - ref_mean, 2)
    return shift

def generate_tamper_report(test_path, matched_emp_path):
    pitch_shift = detect_pitch_shift(test_path, matched_emp_path)

    tampered = abs(pitch_shift) > 100  # threshold can be adjusted
    report = {
        "Pitch_Shift_Hz": pitch_shift,
        "Tampering_Detected": tampered
    }
    return report

# Example test
if __name__ == "__main__":
    report = generate_tamper_report("test_voices/masked_emp1.wav", "emp_voices/emp1.wav")
    print("📝 Tamper Report:")
    print(report)
