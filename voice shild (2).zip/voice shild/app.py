# app.py

import streamlit as st
from voice_matcher import match_speaker
from tamper_report_generator import generate_tamper_report

st.title("🔊 VoiceShield – AI Voice Detection and Matching")

uploaded = st.file_uploader("Upload suspicious voice (.wav)", type="wav")

if uploaded:
    with open("temp.wav", "wb") as f:
        f.write(uploaded.read())

    st.audio("temp.wav")
    matched_emp, confidence = match_speaker("temp.wav", "emp_voices")
    report = generate_tamper_report("temp.wav", f"emp_voices/{matched_emp}")

    st.success(f"✅ Likely Speaker: {matched_emp}")
    st.info(f"🔁 Confidence Score: {confidence}")
    st.warning(f"📊 Pitch Shift: {report['Pitch_Shift_Hz']} Hz")
    if report["Tampering_Detected"]:
        st.error("⚠️ Tampering Detected!")
    else:
        st.success("✅ No Tampering Detected")
