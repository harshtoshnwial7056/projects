import os
import librosa
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# --- Feature extractor ---
def extract_features_from_folder(folder):
    features = []
    for filename in os.listdir(folder):
        if filename.endswith(".wav"):
            file_path = os.path.join(folder, filename)
            y, sr = librosa.load(file_path, sr=22050)
            mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
            mean_mfcc = np.mean(mfcc.T, axis=0)
            features.append(mean_mfcc)
    return features

# --- Neural network ---
class SimpleNN(nn.Module):
    def __init__(self):
        super(SimpleNN, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(13, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)

# --- Load features ---
ai_features = extract_features_from_folder("ai_voice_samples")
human_features = extract_features_from_folder("human_voices")  # UPDATED HERE

X = ai_features + human_features
y = [1] * len(ai_features) + [0] * len(human_features)  # 1 = AI, 0 = Human

X_tensor = torch.tensor(X, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)

# --- Training ---
model = SimpleNN()
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

for epoch in range(200):
    outputs = model(X_tensor)
    loss = criterion(outputs, y_tensor)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

# --- Save model ---
torch.save(model.state_dict(), "ai_detector.pth")
print("✅ Model trained and saved as ai_detector.pth")
