import requests
import os

# Ensure folder exists
os.makedirs("VoiceShield/data/human", exist_ok=True)

# Better .wav links for human voice
urls = [
    ("https://www2.cs.uic.edu/~i101/SoundFiles/gettysburg10.wav", "human_voice1.wav"),
    ("https://file-examples.com/storage/fe0a59ddcb0fcebe4eecfd9/2017/11/file_example_WAV_1MG.wav", "human_voice2.wav"),
    ("https://file-examples.com/storage/fe0a59ddcb0fcebe4eecfd9/2017/11/file_example_WAV_2MG.wav", "human_voice3.wav"),
]

# Download files
for url, filename in urls:
    print(f"🔽 Downloading {filename}...")
    try:
        response = requests.get(url, timeout=20)
        response.raise_for_status()
        with open(f"VoiceShield/data/human/{filename}", "wb") as f:
            f.write(response.content)
        print(f"✅ {filename} downloaded.")
    except Exception as e:
        print(f"❌ Failed to download {filename}: {e}")

print("✅ Done downloading all available human voices.")
