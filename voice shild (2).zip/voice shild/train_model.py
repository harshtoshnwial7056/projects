import os
import librosa
import numpy as np
import soundfile as sf
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

def extract_features(file_path):
    try:
        y, sr = librosa.load(file_path, sr=None)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        return np.mean(mfcc.T, axis=0)
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

def load_dataset(data_dir, label):
    features, labels = [], []
    for fname in os.listdir(data_dir):
        if fname.endswith('.wav'):
            path = os.path.join(data_dir, fname)
            feat = extract_features(path)
            if feat is not None:
                features.append(feat)
                labels.append(label)
    return features, labels

# Load both classes
human_features, human_labels = load_dataset('data/human', 0)  # 0 = human
ai_features, ai_labels = load_dataset('data/ai', 1)            # 1 = AI

X = np.array(human_features + ai_features)
y = np.array(human_labels + ai_labels)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

# Save model
joblib.dump(model, 'ai_detector.pkl')
print("✅ Model trained and saved as ai_detector.pkl")
