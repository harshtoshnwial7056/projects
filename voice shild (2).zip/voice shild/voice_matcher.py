# voice_matcher.py

import os
import numpy as np
from resemblyzer import VoiceEncoder, preprocess_wav
from scipy.spatial.distance import cosine

# Load speaker encoder model
encoder = VoiceEncoder()

# Generate speaker embedding from audio file
def get_embedding(file_path):
    wav = preprocess_wav(file_path)
    return encoder.embed_utterance(wav)

# Match test voice with closest employee voice
def match_speaker(test_path, emp_folder="emp_voices"):
    test_embed = get_embedding(test_path)
    min_dist = float('inf')
    best_match = None

    for emp_file in os.listdir(emp_folder):
        if emp_file.endswith(".wav"):
            emp_path = os.path.join(emp_folder, emp_file)
            emp_embed = get_embedding(emp_path)
            dist = cosine(test_embed, emp_embed)

            if dist < min_dist:
                min_dist = dist
                best_match = emp_file

    return best_match, round(1 - min_dist, 2)  # confidence between 0 and 1

# Quick test
if __name__ == "__main__":
    test_file = "test_voices/masked_emp1.wav"
    matched_emp, confidence = match_speaker(test_file)
    print("🔍 Match Result")
    print(f"Likely Speaker: {matched_emp}")
    print(f"Confidence: {confidence}")
